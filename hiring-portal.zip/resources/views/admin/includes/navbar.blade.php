<ul class="list-unstyled nav_list d-flex flex-wrap gap-2 d-md-block">
    <li><a class="btn mb-3 d-block btn-outline-secondary" href="/admin">Dashboard</a></li>
    <li><a class="btn mb-3 d-block btn-outline-secondary" href="/admin/candidate-list">Candidates</a></li>
    <li><a class="btn mb-3 d-block btn-outline-secondary" href="{{ route('quiz_index') }}">Quizes</a></li>
    <li><a class="btn mb-3 d-block btn-outline-secondary" href="{{ route('question_index') }}">Questions</a></li>
</ul>
