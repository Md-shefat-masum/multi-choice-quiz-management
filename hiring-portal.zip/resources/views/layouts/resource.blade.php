<title>{{ $title ?? 'Dashboard' }}</title>
<!-- Fonts -->
<style>
    @font-face{
        font-family: 'Nunito', sans-serif;;
        src: url('/fonts/static/Nunito-Regular.ttf');
    }
</style>
<link rel="stylesheet" href="/css/app.css">
<link rel="stylesheet" href="/css/custom.css">
<script src="/js/bootstrap.bundle.min.js"></script>
