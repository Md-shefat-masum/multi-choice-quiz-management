<form action="/user/submit-quiz" method="POST" id="quiz_form">
    <?php echo csrf_field(); ?>
    <div class="modal-header">
        <div>
            <h5 class="modal-title" id="exampleModalLabel"><?php echo e($quiz->title); ?></h5>
            <h6 class="text-danger m-0" id="alert_text"></h6>
            <h6 class="text-success m-0" id="success_text"></h6>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
        <div class="modal_quiz_list">
            <?php $__currentLoopData = $quiz->related_quesions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal_quiz shadow-sm p-3 rounded-1">
                    <h5 class="d-flex gap-1">
                        <span>
                            <?php echo e($key+1); ?>.
                        </span>
                        <span id="<?php echo e($question->slug); ?>" class="question_label">
                            <?php echo e($question->title); ?>

                        </span>
                    </h5>
                    <ol type="i">
                        <?php $__currentLoopData = $question->quizQuestionOption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <label for="o<?php echo e($option->id.$key+1); ?>">
                                    <input value="<?php echo e($option->slug); ?>" name="qa[<?php echo e($quiz->id); ?>][<?php echo e($question->id); ?>][]" id="o<?php echo e($option->id.$key+1); ?>" type="checkbox">
                                    <?php echo e($option->title); ?>

                                </label>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-primary d-none" id="quiz_submit_processing_btn" type="submit" disabled>
            <span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>
            Loading...
        </button>
        <button type="submit" id="quiz_submit_btn" class="btn btn-primary">Submit</button>
    </div>
</form>
<?php /**PATH D:\task\hiring-portal\resources\views/user/quiz.blade.php ENDPATH**/ ?>