<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <?php echo $__env->make('admin.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class=" card border-0 shadow-sm">
                    <div class="card-header d-flex justify-content-between">
                        <h5>Create Quiz</h5>
                        <a href="<?php echo e(route('quiz_index')); ?>" class="btn btn-success"><- Back</a>
                    </div>
                    <div class="card-body table-responsive">
                        <form action="<?php echo e(route('quiz_store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-4 d-flex gap-3 align-items-center flex-wrap">
                                <label for="">Title: </label>
                                <input type="text" class="form-control w-75" value="<?php echo e(old('title')); ?>" name="title">
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger w-100"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button class="btn btn-success">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',[
    'title' => 'admin'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\task\hiring-portal\resources\views/admin/quiz/create.blade.php ENDPATH**/ ?>