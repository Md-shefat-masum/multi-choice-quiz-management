
<div class="modal-header">
    <div>
        <h5 class="modal-title" id="exampleModalLabel">
            <?php echo e($quiz->title); ?> ( <?php echo e($quiz->related_quesions->count()); ?> )
        </h5>
    </div>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <div class="modal_quiz_list">
        <?php $__currentLoopData = $quiz->related_quesions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal_quiz shadow-sm p-3 rounded-1">
                <h5 class="d-flex gap-1">
                    <span>
                        <?php echo e($key+1); ?>.
                    </span>
                    <span class="question_label">
                        <?php echo e($question->title); ?>

                    </span>
                </h5>
                <ol type="i">
                    <?php $__currentLoopData = $question->quizQuestionOption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <label>
                                <?php if($option->is_correct): ?>
                                    <input disabled checked type="checkbox">
                                    <span class="text-success"><?php echo e($option->title); ?></span>
                                <?php else: ?>
                                    <input disabled type="checkbox">
                                    <span><?php echo e($option->title); ?></span>
                                <?php endif; ?>
                            </label>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\task\hiring-portal\resources\views/admin/quiz/quiz_details.blade.php ENDPATH**/ ?>