
<div class="modal-header">
    <div>
        <h5 class="modal-title" id="exampleModalLabel">
            <?php echo e($quiz->title); ?> ( <?php echo e($quiz->correct_answer); ?> / <?php echo e($quiz->related_quesions->count()); ?> )
        </h5>
    </div>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <div class="modal_quiz_list">
        <?php $__currentLoopData = $quiz->related_quesions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal_quiz shadow-sm p-3 rounded-1">
                <h5 class="d-flex gap-1">
                    <span>
                        <?php echo e($key+1); ?>.
                    </span>
                    <span class="question_label <?php echo e($question->correct_answer?'text-success':'text-danger'); ?>">
                        <?php echo e($question->title); ?>

                    </span>
                </h5>
                <ol type="i">
                    <?php $__currentLoopData = $question->quizQuestionOption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <label>
                                <?php if($option->user_selected): ?>
                                    <input disabled checked value="<?php echo e($option->slug); ?>" type="checkbox">
                                <?php else: ?>
                                    <input disabled value="<?php echo e($option->slug); ?>" type="checkbox">
                                <?php endif; ?>

                                <?php if($option->is_correct && $option->user_selected_correct): ?>
                                    <span class="text-success">
                                        <?php echo e($option->title); ?>

                                    </span>
                                <?php elseif($option->is_correct && !$option->user_selected_correct): ?>
                                    <span class="text-success">
                                        <?php echo e($option->title); ?>

                                    </span>
                                <?php elseif(!$option->is_correct && $option->user_selected_correct): ?>
                                    <span class="text-danger">
                                        <?php echo e($option->title); ?>

                                    </span>
                                <?php elseif(!$option->is_correct && $option->user_selected): ?>
                                    <span class="text-danger">
                                        <?php echo e($option->title); ?>

                                    </span>
                                <?php else: ?>
                                    <span><?php echo e($option->title); ?></span>
                                <?php endif; ?>
                            </label>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\task\hiring-portal\resources\views/user/quiz_result.blade.php ENDPATH**/ ?>