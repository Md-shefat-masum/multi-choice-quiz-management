<title><?php echo e($title ?? 'Dashboard'); ?></title>
<!-- Fonts -->
<style>
    @font-face{
        font-family: 'Nunito', sans-serif;;
        src: url('/fonts/static/Nunito-Regular.ttf');
    }
</style>
<link rel="stylesheet" href="/css/app.css">
<link rel="stylesheet" href="/css/custom.css">
<script src="/js/bootstrap.bundle.min.js"></script>
<?php /**PATH D:\task\hiring-portal\resources\views/layouts/resource.blade.php ENDPATH**/ ?>