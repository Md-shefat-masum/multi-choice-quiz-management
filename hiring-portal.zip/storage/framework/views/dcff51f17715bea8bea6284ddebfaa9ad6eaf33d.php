<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php echo $__env->make('layouts.resource',[
            'title' => 'Hiring portal',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>
        <section >
            <div class="container home_container">
                <div class="card shadow border-0">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="/images/image.png" class="img-fluid" alt="">
                            </div>
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <?php if(session()->has('alert')): ?>
            <div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
                <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                    <div class="toast-header">
                        
                        <strong class="me-auto">Access denied</strong>
                        <small>1 sec ago</small>
                        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                    </div>
                    <div class="toast-body">
                        <?php echo e(session()->get('alert')); ?>

                    </div>
                </div>
            </div>

            <script defer>
                var toastLiveExample = document.getElementById('liveToast');
                var toast = new bootstrap.Toast(toastLiveExample)
                toast.show()
            </script>
        <?php endif; ?>
    </body>
</html>
<?php /**PATH D:\task\hiring-portal\resources\views/layouts/guest.blade.php ENDPATH**/ ?>