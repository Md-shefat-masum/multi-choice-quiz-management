<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <?php echo $__env->make('admin.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class=" card border-0 shadow-sm">
                    <div class="card-header d-flex justify-content-between">
                        <h5>Create Question</h5>
                        <a href="<?php echo e(route('question_index')); ?>" class="btn btn-success"><- Back</a>
                    </div>
                    <div class="card-body table-responsive">
                        <form id="quiz_question_form" action="<?php echo e(route('question_store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            
                            <table class="table quiz_creation_table table-hover">
                                <thead>
                                    <tr>
                                        <th>SI</th>
                                        <th>Title</th>
                                        <th>Options</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="5" class="text-center">
                                            <button type="button" onclick="add_question()" class="btn btn-sm btn-warning">append more</button>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                            <button id="submit_btn" class="btn btn-success">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('cjs'); ?>

        <script src="/js/admin.js"></script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',[
    'title' => 'admin'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\task\hiring-portal\resources\views/admin/question/create.blade.php ENDPATH**/ ?>